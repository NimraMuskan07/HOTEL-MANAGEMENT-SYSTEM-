﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace hotel_management_system
{
    public partial class category : Form
    {
        string flag,fnameb,lnameb,passwordb;
        public category(string flag, string fnameb, string lnameb, string passwordb)
        {
            this.flag = flag;
            this.fnameb = fnameb;
            this.lnameb = lnameb;
            this.passwordb = passwordb;
          
            InitializeComponent();
        }

        private void fastFood_Click(object sender, EventArgs e)
        {
            this.Hide();
            fastFood ffood = new fastFood(flag, fnameb, lnameb, passwordb);
            ffood.ShowDialog();
        }

        private void contienental_Click(object sender, EventArgs e)
        {
            this.Hide();
            contienental cont = new contienental(flag, fnameb, lnameb, passwordb);
            cont.ShowDialog();
        }

        private void chinese_Click(object sender, EventArgs e)
        {
            this.Hide();
            chinese chineese = new chinese(flag, fnameb, lnameb, passwordb);
            chineese.ShowDialog();
        }

        private void bbq_Click(object sender, EventArgs e)
        {  
            this.Hide();
            BBQ bbq = new BBQ(flag, fnameb, lnameb, passwordb);
            bbq.ShowDialog();
        }

        private void desi_Click(object sender, EventArgs e)
        {
            this.Hide();
            desi desi = new desi(flag, fnameb, lnameb, passwordb);
            desi.ShowDialog();
        }

        private void local_Click(object sender, EventArgs e)
        {
            this.Hide();
            local locals = new local(flag, fnameb, lnameb, passwordb);
            locals.ShowDialog();
        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Hide();
            home h1 = new home();
            h1.ShowDialog();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Category_Load(object sender, EventArgs e)
        {

        }

        private void Orderbtn_Click(object sender, EventArgs e)
        {
            if (flag == "1")
            {
                this.Hide();
                cart cart1 = new cart(flag, fnameb, lnameb, passwordb);
                cart1.ShowDialog();
            }
            else
            {
                MessageBox.Show("You Cannot Order \n Login First!");
            }
        }

        private void Confirmbtn_Click(object sender, EventArgs e)
        {
            if(flag == "1")
            {
                DateTime now = DateTime.Now;
                string nowdt = now.ToString("F");
                this.Hide();
                final final1 = new final(flag,fnameb,lnameb,passwordb, nowdt);
                final1.ShowDialog();
            }
            else
            {
                MessageBox.Show("You Cannot Order \n Login First!");
            }
            
        }
    }
}
