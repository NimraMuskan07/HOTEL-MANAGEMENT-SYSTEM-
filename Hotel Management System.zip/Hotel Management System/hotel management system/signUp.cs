﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace hotel_management_system
{
    public partial class signUp : Form
    {
        public signUp()
        {
            InitializeComponent();
        }

        private void sign_up_Click(object sender, EventArgs e)
        {
            if(fnametxt.Text == "" || lnametxt.Text == "" || passtxt.Text == "" || repasstxt.Text == "")
            {
                MessageBox.Show("Data required");
            }
            else
            {
                if (passtxt.Text == repasstxt.Text)
                {
                    MySqlConnection connection = new MySqlConnection("datasource=localhost;port=3306;username=root;password=Rowdy123");

                    string insertQuery = "INSERT INTO hotelms.logIn(firstname,lastname,password) VALUES('" + fnametxt.Text + "','" + lnametxt.Text + "','" + passtxt.Text + "')";
                    connection.Open();
                    MySqlCommand command = new MySqlCommand(insertQuery, connection);

                    try
                    {
                        if (command.ExecuteNonQuery() == 1)
                        {
                            MessageBox.Show("Data Inserted");
                            fnametxt.Clear();
                            lnametxt.Clear();
                            passtxt.Clear();
                            repasstxt.Clear();

                        }
                        else
                        {
                            MessageBox.Show("Data not Selected");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }

                    connection.Close();
                }
                else
                {
                    MessageBox.Show("Password not matched");
                }
            }
        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Hide();
            logIn l1 = new logIn();
            l1.ShowDialog();
        }

        private void SignUp_Load(object sender, EventArgs e)
        {
            
        }
    }
}
