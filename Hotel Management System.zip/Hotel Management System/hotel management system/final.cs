﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Configuration;

namespace hotel_management_system
{
    public partial class final : Form
    {
        string flag,fnameb,lnameb,passwordb,nowdt;
        public final(string flag, string fnameb, string lnameb, string passwordb,string nowdt)
        {
            this.flag = flag;
            this.fnameb = fnameb;
            this.lnameb = lnameb;
            this.passwordb = passwordb;
            this.nowdt = nowdt;


            InitializeComponent();
        }

        private void viewBill_Click(object sender, EventArgs e)
        {
            
            this.Hide();
            bill item1 = new bill(fnameb,lnameb,passwordb,nowdt);
            item1.ShowDialog();
        }

        private void logOut_Click(object sender, EventArgs e)
        {
            MySqlConnection connection = new MySqlConnection("datasource=localhost;port=3306;username=root;password=Rowdy123");

            MessageBox.Show("You are Logged Out!");
            flag = "0";

            connection.Open();
            string query = "TRUNCATE TABLE hotelms.cart";
            MySqlCommand cmd = new MySqlCommand(query, connection);
            cmd.ExecuteNonQuery();
            connection.Close();

            category cate4 = new category(flag, fnameb, lnameb, passwordb);
        }

        private void Final_Load(object sender, EventArgs e)
        {
        }

        private void Exitbtn_Click(object sender, EventArgs e)
        {
            DialogResult A = MessageBox.Show("Are you sure to Exit?", "Exit?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (A == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

       
    }
}
