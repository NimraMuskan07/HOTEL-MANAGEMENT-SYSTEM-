﻿namespace hotel_management_system
{
    partial class signUp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.sign_up = new System.Windows.Forms.Button();
            this.back = new System.Windows.Forms.Button();
            this.fnametxt = new System.Windows.Forms.TextBox();
            this.passtxt = new System.Windows.Forms.TextBox();
            this.name = new System.Windows.Forms.Label();
            this.passowrd = new System.Windows.Forms.Label();
            this.lnametxt = new System.Windows.Forms.TextBox();
            this.repasstxt = new System.Windows.Forms.TextBox();
            this.email = new System.Windows.Forms.Label();
            this.reWritePass = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // sign_up
            // 
            this.sign_up.BackColor = System.Drawing.Color.SlateGray;
            this.sign_up.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sign_up.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sign_up.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.sign_up.Location = new System.Drawing.Point(162, 217);
            this.sign_up.Name = "sign_up";
            this.sign_up.Size = new System.Drawing.Size(119, 23);
            this.sign_up.TabIndex = 13;
            this.sign_up.Text = "Create New Account";
            this.sign_up.UseVisualStyleBackColor = false;
            this.sign_up.Click += new System.EventHandler(this.sign_up_Click);
            // 
            // back
            // 
            this.back.BackColor = System.Drawing.Color.SlateGray;
            this.back.Cursor = System.Windows.Forms.Cursors.Hand;
            this.back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.back.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.back.Location = new System.Drawing.Point(64, 217);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(56, 23);
            this.back.TabIndex = 12;
            this.back.Text = "back";
            this.back.UseVisualStyleBackColor = false;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // fnametxt
            // 
            this.fnametxt.Location = new System.Drawing.Point(181, 35);
            this.fnametxt.Name = "fnametxt";
            this.fnametxt.Size = new System.Drawing.Size(100, 20);
            this.fnametxt.TabIndex = 1;
            // 
            // passtxt
            // 
            this.passtxt.Location = new System.Drawing.Point(181, 97);
            this.passtxt.Name = "passtxt";
            this.passtxt.Size = new System.Drawing.Size(100, 20);
            this.passtxt.TabIndex = 3;
            this.passtxt.UseSystemPasswordChar = true;
            // 
            // name
            // 
            this.name.AutoSize = true;
            this.name.Location = new System.Drawing.Point(92, 38);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(58, 13);
            this.name.TabIndex = 9;
            this.name.Text = "First name:";
            // 
            // passowrd
            // 
            this.passowrd.AutoSize = true;
            this.passowrd.Location = new System.Drawing.Point(95, 100);
            this.passowrd.Name = "passowrd";
            this.passowrd.Size = new System.Drawing.Size(56, 13);
            this.passowrd.TabIndex = 8;
            this.passowrd.Text = "Password:";
            // 
            // lnametxt
            // 
            this.lnametxt.Location = new System.Drawing.Point(181, 62);
            this.lnametxt.Name = "lnametxt";
            this.lnametxt.Size = new System.Drawing.Size(100, 20);
            this.lnametxt.TabIndex = 2;
            // 
            // repasstxt
            // 
            this.repasstxt.Location = new System.Drawing.Point(181, 140);
            this.repasstxt.Name = "repasstxt";
            this.repasstxt.Size = new System.Drawing.Size(100, 20);
            this.repasstxt.TabIndex = 4;
            this.repasstxt.UseSystemPasswordChar = true;
            // 
            // email
            // 
            this.email.AutoSize = true;
            this.email.Location = new System.Drawing.Point(91, 65);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(59, 13);
            this.email.TabIndex = 15;
            this.email.Text = "Last name:";
            // 
            // reWritePass
            // 
            this.reWritePass.AutoSize = true;
            this.reWritePass.Location = new System.Drawing.Point(61, 147);
            this.reWritePass.Name = "reWritePass";
            this.reWritePass.Size = new System.Drawing.Size(94, 13);
            this.reWritePass.TabIndex = 14;
            this.reWritePass.Text = "Confirm Password:";
            // 
            // signUp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(363, 314);
            this.ControlBox = false;
            this.Controls.Add(this.lnametxt);
            this.Controls.Add(this.repasstxt);
            this.Controls.Add(this.email);
            this.Controls.Add(this.reWritePass);
            this.Controls.Add(this.sign_up);
            this.Controls.Add(this.back);
            this.Controls.Add(this.fnametxt);
            this.Controls.Add(this.passtxt);
            this.Controls.Add(this.name);
            this.Controls.Add(this.passowrd);
            this.Name = "signUp";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "signUp";
            this.Load += new System.EventHandler(this.SignUp_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button sign_up;
        private System.Windows.Forms.Button back;
        private System.Windows.Forms.TextBox fnametxt;
        private System.Windows.Forms.TextBox passtxt;
        private System.Windows.Forms.Label name;
        private System.Windows.Forms.Label passowrd;
        private System.Windows.Forms.TextBox lnametxt;
        private System.Windows.Forms.TextBox repasstxt;
        private System.Windows.Forms.Label email;
        private System.Windows.Forms.Label reWritePass;
    }
}