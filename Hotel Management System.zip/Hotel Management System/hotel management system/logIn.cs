﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Configuration;
using System.Drawing.Imaging;

namespace hotel_management_system
{
    public partial class logIn : Form
    {
        MySqlConnection connection = new MySqlConnection("datasource=localhost;port=3306;username=root;password=Rowdy123");
        MySqlDataAdapter adapter;
        DataTable table = new DataTable();
        string flag,fnameb,lnameb,passwordb;

        public logIn()
        {
            InitializeComponent();
        }

        private void log_in_Click(object sender, EventArgs e)
        {
            adapter = new MySqlDataAdapter("SELECT `firstname`,`lastname`,`password` FROM hotelms.login WHERE `firstname` = '" + fnametxt.Text + "' AND `lastname` = '" + lnametxt.Text + "' AND `password` = '" + passtxt.Text + "'", connection);
            adapter.Fill(table);

            if (table.Rows.Count <= 0)
            {
                MessageBox.Show("Invalid");
                fnametxt.Clear();
                lnametxt.Clear();
                passtxt.Clear();
                fnametxt.Focus();
            }
            else
            {
                flag = "1";
                fastFood ffood2 = new fastFood(flag, fnameb, lnameb, passwordb);

                fnameb = fnametxt.Text;
                lnameb = lnametxt.Text;
                passwordb = passtxt.Text;
              
                connection.Open();
                string query = "TRUNCATE TABLE hotelms.cart";
                MySqlCommand cmd = new MySqlCommand(query, connection);
                cmd.ExecuteNonQuery();
                connection.Close();

                this.Hide();
                category c1 = new category(flag,fnameb,lnameb,passwordb);
                c1.ShowDialog();
            }
            table.Clear();
        }

        private void signUp_Click(object sender, EventArgs e)
        {
            this.Hide();
            signUp s1 = new signUp();
            s1.ShowDialog();
        }

        private void lnametxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void fnametxt_Enter(object sender, EventArgs e)
        {
            if (fnametxt.Text == "First Name")
            {
                fnametxt.Text = "";
                fnametxt.ForeColor = Color.Black;

            }
        }

        private void fnametxt_Leave(object sender, EventArgs e)
        {
            if (fnametxt.Text == "")
            {
                fnametxt.Text = "First Name";
                fnametxt.ForeColor = Color.Silver;

            }
        }

        private void lnametxt_Enter(object sender, EventArgs e)
        {
            if (lnametxt.Text == "Last Name")
            {
                lnametxt.Text = "";
                lnametxt.ForeColor = Color.Black;

            }
        }

        private void lnametxt_Leave(object sender, EventArgs e)
        {
            if (lnametxt.Text == "")
            {
                lnametxt.Text = "Last Name";
                lnametxt.ForeColor = Color.Silver;

            }
        }

        private void passtxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void passtxt_Enter(object sender, EventArgs e)
        {
            if (passtxt.Text == "Password")
            {
                passtxt.Text = "";
                passtxt.ForeColor = Color.Black;

            }
        }

        private void passtxt_Leave(object sender, EventArgs e)
        {
            if (passtxt.Text == "")
            {
                passtxt.Text = "Password";
                passtxt.ForeColor = Color.Silver;

            }
        }

        private void fnametxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Hide();
            home h1 = new home();
            h1.ShowDialog();
        }

        private void LogIn_Load(object sender, EventArgs e)
        {
            
          

           
        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }

        private void passtxt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                log_in_Click(null, null);
            }
        }

        private void fnametxt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                lnametxt.Focus();
            }
        }

        private void lnametxt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                passtxt.Focus();
            }
        }
    }
}
