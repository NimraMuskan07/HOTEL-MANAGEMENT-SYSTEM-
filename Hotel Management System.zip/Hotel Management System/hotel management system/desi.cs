﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Configuration;

namespace hotel_management_system
{
    public partial class desi : Form
    {
        string flag, fnameb, lnameb, passwordb;
        int select;

        public desi(string flag, string fnameb, string lnameb, string passwordb)
        {
            this.flag = flag;
            this.fnameb = fnameb;
            this.lnameb = lnameb;
            this.passwordb = passwordb;
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Desi_Load(object sender, EventArgs e)
        {
            try
            {
                MySqlConnection connection = new MySqlConnection("datasource=localhost;port=3306;username=root;password=Rowdy123");
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT * FROM hotelms.desi", connection);
                connection.Open();


                DataSet ds = new DataSet();
                adapter.Fill(ds, "desi");
                dataGridView1.DataSource = ds.Tables["desi"];
                connection.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            DataGridViewCheckBoxColumn chkbox = new DataGridViewCheckBoxColumn();
            chkbox.HeaderText = "";
            chkbox.Width = 30;
            chkbox.Name = "CheckBoxColumn";

            dataGridView1.Columns.Insert(3, chkbox);
        }

        private void Backbtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            category c6 = new category(flag, fnameb, lnameb, passwordb);
            c6.ShowDialog();
        }

        private void Savebtn_Click(object sender, EventArgs e)
        {
            if(flag == "1")
            { 
                string mainconn = ConfigurationManager.ConnectionStrings["Myconnection"].ConnectionString;
                MySqlConnection sqlconn = new MySqlConnection(mainconn);

                foreach (DataGridViewRow dr in dataGridView1.Rows)
                {
                    bool chkboxselected = Convert.ToBoolean(dr.Cells["CheckBoxColumn"].Value);
                    if (chkboxselected)
                    {
                        select = 1;
                        string sqlquery = "INSERT INTO hotelms.cart values(@id,@name,@price)";
                        MySqlCommand sqlcomm = new MySqlCommand(sqlquery, sqlconn);
                        sqlcomm.Parameters.AddWithValue("@id", dr.Cells["id"].Value ?? DBNull.Value);
                        sqlcomm.Parameters.AddWithValue("@name", dr.Cells["name"].Value ?? DBNull.Value);
                        sqlcomm.Parameters.AddWithValue("@price", dr.Cells["price"].Value ?? DBNull.Value);
                        sqlconn.Open();
                        sqlcomm.ExecuteNonQuery();
                        sqlconn.Close();
                    }
                }
                if (select == 1)
                {

                    MessageBox.Show("added to cart!");
                }
                else
                {
                    MessageBox.Show("Select some quantity!");
                }
            }

            else
            {
                MessageBox.Show("You Cannot Order \n Login First!");
            }
        }
    }
}
