﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Configuration;

namespace hotel_management_system
{
    public partial class cart : Form
    {
        MySqlConnection connection = new MySqlConnection("datasource=localhost;port=3306;username=root;password=Rowdy123");

        string flag, fnameb, lnameb, passwordb;
        int remove = 0;
        public cart(string flag, string fnameb, string lnameb, string passwordb)
        {
            this.flag = flag;
            this.fnameb = fnameb;
            this.lnameb = lnameb;
            this.passwordb = passwordb;
            InitializeComponent();
        }

        private void DataGridView1_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            dataGridView1.Rows[e.RowIndex].Cells[0].Value=(e.RowIndex+1).ToString();
        }

        private void Removebtn_Click(object sender, EventArgs e)
        {
            string mainconn = ConfigurationManager.ConnectionStrings["Myconnection"].ConnectionString;
            MySqlConnection sqlconn = new MySqlConnection(mainconn);

            foreach (DataGridViewRow item in dataGridView1.Rows)
            {
                bool chkboxselected = Convert.ToBoolean(item.Cells["CheckBoxColumn"].Value);

                if (chkboxselected)
                {
                    remove = 1;
                    string sqlquery = "DELETE from hotelms.cart WHERE id ='" + item.Cells[remove].Value.ToString() + "'";
                    MySqlCommand sqlcomm = new MySqlCommand(sqlquery, sqlconn);

                    sqlconn.Open();
                    sqlcomm.ExecuteNonQuery();
                    sqlconn.Close();
                }
            }
            if(remove == 1)
            {
                MessageBox.Show("Successfully Deleted!");
                DataGridViewCheckBoxColumn chkbox2 = new DataGridViewCheckBoxColumn();

            }
            else
            {
                MessageBox.Show("Select some quantity!");
            }

            
             try
            {
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT * FROM hotelms.cart", connection);

                connection.Open();
                DataSet ds = new DataSet();
                adapter.Fill(ds, "cart");
                dataGridView1.DataSource = ds.Tables["cart"];

                MySqlCommand total = new MySqlCommand("SELECT sum(price) as Total from hotelms.cart", connection);
                MySqlDataReader reader;
                reader = total.ExecuteReader();
                while (reader.Read())
                {
                    totaltxtbox.Text = reader["Total"].ToString();

                }
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            DataGridViewCheckBoxColumn chkbox = new DataGridViewCheckBoxColumn();
            chkbox.HeaderText = "";
            chkbox.Width = 30;
            chkbox.Name = "CheckBoxColumn";

            
        }

        private void Cart_Load(object sender, EventArgs e)
        {
            
            try
            {
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT * FROM hotelms.cart", connection);

                connection.Open();
                DataSet ds = new DataSet();
                adapter.Fill(ds, "cart");
                dataGridView1.DataSource = ds.Tables["cart"];

                MySqlCommand total = new MySqlCommand("SELECT sum(price) as Total from hotelms.cart", connection);
                MySqlDataReader reader;
                reader = total.ExecuteReader();
                while (reader.Read())
                {
                    totaltxtbox.Text = reader["Total"].ToString();

                }
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            DataGridViewCheckBoxColumn chkbox = new DataGridViewCheckBoxColumn();
            chkbox.HeaderText = "";
            chkbox.Width = 30;
            chkbox.Name = "CheckBoxColumn";

            dataGridView1.Columns.Insert(4, chkbox);

        }

        private void Backbtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            category cate3 = new category(flag, fnameb, lnameb, passwordb);
            cate3.ShowDialog();
        }

        private void DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
