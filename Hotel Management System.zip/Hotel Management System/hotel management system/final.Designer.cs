﻿namespace hotel_management_system
{
    partial class final
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.viewBill = new System.Windows.Forms.Button();
            this.logOut = new System.Windows.Forms.Button();
            this.exitbtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // viewBill
            // 
            this.viewBill.Location = new System.Drawing.Point(112, 46);
            this.viewBill.Name = "viewBill";
            this.viewBill.Size = new System.Drawing.Size(75, 23);
            this.viewBill.TabIndex = 0;
            this.viewBill.Text = "view bill";
            this.viewBill.UseVisualStyleBackColor = true;
            this.viewBill.Click += new System.EventHandler(this.viewBill_Click);
            // 
            // logOut
            // 
            this.logOut.Location = new System.Drawing.Point(112, 100);
            this.logOut.Name = "logOut";
            this.logOut.Size = new System.Drawing.Size(75, 23);
            this.logOut.TabIndex = 1;
            this.logOut.Text = "log out";
            this.logOut.UseVisualStyleBackColor = true;
            this.logOut.Click += new System.EventHandler(this.logOut_Click);
            // 
            // exitbtn
            // 
            this.exitbtn.Location = new System.Drawing.Point(112, 155);
            this.exitbtn.Name = "exitbtn";
            this.exitbtn.Size = new System.Drawing.Size(75, 23);
            this.exitbtn.TabIndex = 3;
            this.exitbtn.Text = "EXIT";
            this.exitbtn.UseVisualStyleBackColor = true;
            this.exitbtn.Click += new System.EventHandler(this.Exitbtn_Click);
            // 
            // final
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.ControlBox = false;
            this.Controls.Add(this.exitbtn);
            this.Controls.Add(this.logOut);
            this.Controls.Add(this.viewBill);
            this.Name = "final";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "final";
            this.Load += new System.EventHandler(this.Final_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button viewBill;
        private System.Windows.Forms.Button logOut;
        private System.Windows.Forms.Button exitbtn;
    }
}