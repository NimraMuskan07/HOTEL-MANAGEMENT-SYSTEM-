﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Configuration;

namespace hotel_management_system
{
    public partial class bill : Form
    {
        string flag,fnameb,lnameb,passwordb,nowdt;
        public bill(string fnameb, string lnameb, string passwordb,string nowdt)
        {
            this.fnameb = fnameb;
            this.lnameb = lnameb;
            this.passwordb = passwordb;
            this.nowdt = nowdt;


            InitializeComponent();
        }

        private void Fnametxtbox_TextChanged(object sender, EventArgs e)
        {
            
            
        }

        private void Lnametxtbox_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void Lnamelbl_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (button1.Text == "SAH HOTEL BY Sooraj Ashish Huzaifa.")
            {
                button1.Text = "Thank You For Visiting Here.";
            }
            else if (button1.Text == "Thank You For Visiting Here.") {
                button1.Text = "SAH HOTEL BY Sooraj Ashish Huzaifa.";
            }
        }

        private void Totaltxtbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void DataGridView1_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            dataGridView1.Rows[e.RowIndex].Cells[0].Value = (e.RowIndex + 1).ToString();

        }

        private void ItemDetail_Load(object sender, EventArgs e)
        {
            dtlbl.Text = nowdt;
            fnametxtbox.Text = fnameb;
            lnametxtbox.Text = lnameb;
            try
            {
                MySqlConnection connection = new MySqlConnection("datasource=localhost;port=3306;username=root;password=Rowdy123");
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT * FROM hotelms.cart", connection);

                connection.Open();
                DataSet ds = new DataSet();
                adapter.Fill(ds, "cart");
                dataGridView1.DataSource = ds.Tables["cart"];

                MySqlCommand total = new MySqlCommand("SELECT sum(price) as Total from hotelms.cart", connection);
                MySqlDataReader reader;
                reader = total.ExecuteReader();
                while (reader.Read())
                {
                    totaltxtbox.Text = reader["Total"].ToString();

                }
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            DataGridViewCheckBoxColumn chkbox = new DataGridViewCheckBoxColumn();
            chkbox.HeaderText = "";
            chkbox.Width = 30;
            chkbox.Name = "CheckBoxColumn";
        }

        private void Backbtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            final final2 = new final(flag,fnameb,lnameb,passwordb,nowdt);
            final2.ShowDialog();
        }
    }
}
