﻿namespace hotel_management_system
{
    partial class category
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(category));
            this.back = new System.Windows.Forms.Button();
            this.orderbtn = new System.Windows.Forms.Button();
            this.confirmbtn = new System.Windows.Forms.Button();
            this.local = new System.Windows.Forms.Button();
            this.desi = new System.Windows.Forms.Button();
            this.bbq = new System.Windows.Forms.Button();
            this.chinese = new System.Windows.Forms.Button();
            this.contienental = new System.Windows.Forms.Button();
            this.fastFood = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // back
            // 
            this.back.BackColor = System.Drawing.SystemColors.Highlight;
            this.back.Cursor = System.Windows.Forms.Cursors.Hand;
            this.back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.back.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.back.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.back.Location = new System.Drawing.Point(555, 527);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(75, 23);
            this.back.TabIndex = 6;
            this.back.Text = "Log Out";
            this.back.UseVisualStyleBackColor = false;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // orderbtn
            // 
            this.orderbtn.BackColor = System.Drawing.SystemColors.Highlight;
            this.orderbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.orderbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.orderbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.orderbtn.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.orderbtn.Location = new System.Drawing.Point(-1, 527);
            this.orderbtn.Name = "orderbtn";
            this.orderbtn.Size = new System.Drawing.Size(75, 23);
            this.orderbtn.TabIndex = 7;
            this.orderbtn.Text = "View Order";
            this.orderbtn.UseVisualStyleBackColor = false;
            this.orderbtn.Click += new System.EventHandler(this.Orderbtn_Click);
            // 
            // confirmbtn
            // 
            this.confirmbtn.BackColor = System.Drawing.SystemColors.Highlight;
            this.confirmbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.confirmbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.confirmbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.confirmbtn.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.confirmbtn.Location = new System.Drawing.Point(256, 527);
            this.confirmbtn.Name = "confirmbtn";
            this.confirmbtn.Size = new System.Drawing.Size(117, 23);
            this.confirmbtn.TabIndex = 8;
            this.confirmbtn.Text = "Confirm Order";
            this.confirmbtn.UseVisualStyleBackColor = false;
            this.confirmbtn.Click += new System.EventHandler(this.Confirmbtn_Click);
            // 
            // local
            // 
            this.local.Cursor = System.Windows.Forms.Cursors.Hand;
            this.local.Image = global::hotel_management_system.Properties.Resources.local;
            this.local.Location = new System.Drawing.Point(325, 335);
            this.local.Name = "local";
            this.local.Size = new System.Drawing.Size(305, 144);
            this.local.TabIndex = 5;
            this.local.UseVisualStyleBackColor = true;
            this.local.Click += new System.EventHandler(this.local_Click);
            // 
            // desi
            // 
            this.desi.Cursor = System.Windows.Forms.Cursors.Hand;
            this.desi.Image = ((System.Drawing.Image)(resources.GetObject("desi.Image")));
            this.desi.Location = new System.Drawing.Point(-1, 337);
            this.desi.Name = "desi";
            this.desi.Size = new System.Drawing.Size(305, 144);
            this.desi.TabIndex = 4;
            this.desi.UseVisualStyleBackColor = true;
            this.desi.Click += new System.EventHandler(this.desi_Click);
            // 
            // bbq
            // 
            this.bbq.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bbq.Image = global::hotel_management_system.Properties.Resources.bbq;
            this.bbq.Location = new System.Drawing.Point(325, 169);
            this.bbq.Name = "bbq";
            this.bbq.Size = new System.Drawing.Size(305, 138);
            this.bbq.TabIndex = 3;
            this.bbq.UseVisualStyleBackColor = true;
            this.bbq.Click += new System.EventHandler(this.bbq_Click);
            // 
            // chinese
            // 
            this.chinese.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chinese.Image = ((System.Drawing.Image)(resources.GetObject("chinese.Image")));
            this.chinese.Location = new System.Drawing.Point(-1, 169);
            this.chinese.Name = "chinese";
            this.chinese.Size = new System.Drawing.Size(305, 138);
            this.chinese.TabIndex = 2;
            this.chinese.UseVisualStyleBackColor = true;
            this.chinese.Click += new System.EventHandler(this.chinese_Click);
            // 
            // contienental
            // 
            this.contienental.Cursor = System.Windows.Forms.Cursors.Hand;
            this.contienental.Image = ((System.Drawing.Image)(resources.GetObject("contienental.Image")));
            this.contienental.Location = new System.Drawing.Point(325, 0);
            this.contienental.Name = "contienental";
            this.contienental.Size = new System.Drawing.Size(305, 138);
            this.contienental.TabIndex = 1;
            this.contienental.UseVisualStyleBackColor = true;
            this.contienental.Click += new System.EventHandler(this.contienental_Click);
            // 
            // fastFood
            // 
            this.fastFood.Cursor = System.Windows.Forms.Cursors.Hand;
            this.fastFood.Image = ((System.Drawing.Image)(resources.GetObject("fastFood.Image")));
            this.fastFood.Location = new System.Drawing.Point(-1, 0);
            this.fastFood.Name = "fastFood";
            this.fastFood.Size = new System.Drawing.Size(305, 138);
            this.fastFood.TabIndex = 0;
            this.fastFood.UseVisualStyleBackColor = true;
            this.fastFood.Click += new System.EventHandler(this.fastFood_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(-5, 142);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 24);
            this.label1.TabIndex = 9;
            this.label1.Text = "Fastfood";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(503, 142);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(127, 24);
            this.label2.TabIndex = 10;
            this.label2.Text = "Contienental";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(578, 308);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 24);
            this.label3.TabIndex = 10;
            this.label3.Text = "BBQ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(-2, 310);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 24);
            this.label4.TabIndex = 10;
            this.label4.Text = "Chinese";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(570, 484);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 24);
            this.label5.TabIndex = 10;
            this.label5.Text = "Local";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(-5, 484);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 24);
            this.label6.TabIndex = 11;
            this.label6.Text = "Desi";
            // 
            // category
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(630, 551);
            this.ControlBox = false;
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.confirmbtn);
            this.Controls.Add(this.orderbtn);
            this.Controls.Add(this.back);
            this.Controls.Add(this.local);
            this.Controls.Add(this.desi);
            this.Controls.Add(this.bbq);
            this.Controls.Add(this.chinese);
            this.Controls.Add(this.contienental);
            this.Controls.Add(this.fastFood);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Name = "category";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "category";
            this.Load += new System.EventHandler(this.Category_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button fastFood;
        private System.Windows.Forms.Button contienental;
        private System.Windows.Forms.Button chinese;
        private System.Windows.Forms.Button bbq;
        private System.Windows.Forms.Button desi;
        private System.Windows.Forms.Button local;
        private System.Windows.Forms.Button back;
        private System.Windows.Forms.Button orderbtn;
        private System.Windows.Forms.Button confirmbtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
    }
}