﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace hotel_management_system
{
    public partial class home : Form
    {
        string flag, fnameb, lnameb, passwordb;

        public home()
        {
            InitializeComponent();
        }

        private void logIn_Click(object sender, EventArgs e)
        {
            this.Hide();
            logIn l1 = new logIn();
            l1.ShowDialog();
        }

        private void viewMenu_Click(object sender, EventArgs e)
        {
            this.Hide();
            category c1 = new category(flag, fnameb, lnameb, passwordb);
            c1.ShowDialog();
        }

        private void exit_Click(object sender, EventArgs e)
        {
            DialogResult A = MessageBox.Show("Are you sure to Exit?", "Exit?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (A == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void home_Load(object sender, EventArgs e)
        {

        }

       
    }
}
