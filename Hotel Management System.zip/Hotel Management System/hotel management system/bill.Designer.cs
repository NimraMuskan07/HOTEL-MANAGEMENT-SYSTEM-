﻿namespace hotel_management_system
{
    partial class bill
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.SNO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pricelbl = new System.Windows.Forms.Label();
            this.totaltxtbox = new System.Windows.Forms.TextBox();
            this.backbtn = new System.Windows.Forms.Button();
            this.fnametxtbox = new System.Windows.Forms.TextBox();
            this.lnametxtbox = new System.Windows.Forms.TextBox();
            this.fnamelbl = new System.Windows.Forms.Label();
            this.lnamelbl = new System.Windows.Forms.Label();
            this.dtlbl = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SNO});
            this.dataGridView1.Location = new System.Drawing.Point(105, 132);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(406, 181);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.DataGridView1_RowPostPaint);
            // 
            // SNO
            // 
            this.SNO.HeaderText = "SNO";
            this.SNO.Name = "SNO";
            this.SNO.ReadOnly = true;
            // 
            // pricelbl
            // 
            this.pricelbl.AutoSize = true;
            this.pricelbl.Location = new System.Drawing.Point(347, 325);
            this.pricelbl.Name = "pricelbl";
            this.pricelbl.Size = new System.Drawing.Size(58, 13);
            this.pricelbl.TabIndex = 1;
            this.pricelbl.Text = "Total Price";
            // 
            // totaltxtbox
            // 
            this.totaltxtbox.Location = new System.Drawing.Point(411, 322);
            this.totaltxtbox.Name = "totaltxtbox";
            this.totaltxtbox.Size = new System.Drawing.Size(100, 20);
            this.totaltxtbox.TabIndex = 2;
            this.totaltxtbox.TextChanged += new System.EventHandler(this.Totaltxtbox_TextChanged);
            // 
            // backbtn
            // 
            this.backbtn.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.backbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.backbtn.Location = new System.Drawing.Point(436, 358);
            this.backbtn.Name = "backbtn";
            this.backbtn.Size = new System.Drawing.Size(75, 23);
            this.backbtn.TabIndex = 3;
            this.backbtn.Text = "BACK";
            this.backbtn.UseVisualStyleBackColor = false;
            this.backbtn.Click += new System.EventHandler(this.Backbtn_Click);
            // 
            // fnametxtbox
            // 
            this.fnametxtbox.Location = new System.Drawing.Point(168, 95);
            this.fnametxtbox.Name = "fnametxtbox";
            this.fnametxtbox.Size = new System.Drawing.Size(119, 20);
            this.fnametxtbox.TabIndex = 4;
            this.fnametxtbox.TextChanged += new System.EventHandler(this.Fnametxtbox_TextChanged);
            // 
            // lnametxtbox
            // 
            this.lnametxtbox.Location = new System.Drawing.Point(389, 95);
            this.lnametxtbox.Name = "lnametxtbox";
            this.lnametxtbox.Size = new System.Drawing.Size(122, 20);
            this.lnametxtbox.TabIndex = 5;
            this.lnametxtbox.TextChanged += new System.EventHandler(this.Lnametxtbox_TextChanged);
            // 
            // fnamelbl
            // 
            this.fnamelbl.AutoSize = true;
            this.fnamelbl.Location = new System.Drawing.Point(102, 98);
            this.fnamelbl.Name = "fnamelbl";
            this.fnamelbl.Size = new System.Drawing.Size(60, 13);
            this.fnamelbl.TabIndex = 6;
            this.fnamelbl.Text = "First Name:";
            // 
            // lnamelbl
            // 
            this.lnamelbl.AutoSize = true;
            this.lnamelbl.Location = new System.Drawing.Point(317, 98);
            this.lnamelbl.Name = "lnamelbl";
            this.lnamelbl.Size = new System.Drawing.Size(61, 13);
            this.lnamelbl.TabIndex = 7;
            this.lnamelbl.Text = "Last Name:";
            this.lnamelbl.Click += new System.EventHandler(this.Lnamelbl_Click);
            // 
            // dtlbl
            // 
            this.dtlbl.AutoSize = true;
            this.dtlbl.Location = new System.Drawing.Point(114, 74);
            this.dtlbl.Name = "dtlbl";
            this.dtlbl.Size = new System.Drawing.Size(0, 13);
            this.dtlbl.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(102, 346);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(121, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Thank You for Ordering!";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(284, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "RECEIPT";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(1, 1);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(639, 23);
            this.button1.TabIndex = 11;
            this.button1.Text = "Hotel Management System by Sooraj Kumar";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // bill
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(641, 393);
            this.ControlBox = false;
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dtlbl);
            this.Controls.Add(this.lnamelbl);
            this.Controls.Add(this.fnamelbl);
            this.Controls.Add(this.lnametxtbox);
            this.Controls.Add(this.fnametxtbox);
            this.Controls.Add(this.backbtn);
            this.Controls.Add(this.totaltxtbox);
            this.Controls.Add(this.pricelbl);
            this.Controls.Add(this.dataGridView1);
            this.Name = "bill";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "bill";
            this.Load += new System.EventHandler(this.ItemDetail_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn SNO;
        private System.Windows.Forms.Label pricelbl;
        private System.Windows.Forms.TextBox totaltxtbox;
        private System.Windows.Forms.Button backbtn;
        private System.Windows.Forms.TextBox fnametxtbox;
        private System.Windows.Forms.TextBox lnametxtbox;
        private System.Windows.Forms.Label fnamelbl;
        private System.Windows.Forms.Label lnamelbl;
        private System.Windows.Forms.Label dtlbl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
    }
}