﻿namespace hotel_management_system
{
    partial class logIn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(logIn));
            this.passtxt = new System.Windows.Forms.TextBox();
            this.fnametxt = new System.Windows.Forms.TextBox();
            this.signUp = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.back = new System.Windows.Forms.Button();
            this.log_in = new System.Windows.Forms.Button();
            this.lnametxt = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // passtxt
            // 
            this.passtxt.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.passtxt.Location = new System.Drawing.Point(136, 106);
            this.passtxt.Name = "passtxt";
            this.passtxt.Size = new System.Drawing.Size(146, 20);
            this.passtxt.TabIndex = 3;
            this.passtxt.Text = " Password";
            this.passtxt.UseSystemPasswordChar = true;
            this.passtxt.TextChanged += new System.EventHandler(this.passtxt_TextChanged);
            this.passtxt.Enter += new System.EventHandler(this.passtxt_Enter);
            this.passtxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.passtxt_KeyDown);
            this.passtxt.Leave += new System.EventHandler(this.passtxt_Leave);
            // 
            // fnametxt
            // 
            this.fnametxt.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.fnametxt.Location = new System.Drawing.Point(136, 34);
            this.fnametxt.Name = "fnametxt";
            this.fnametxt.Size = new System.Drawing.Size(146, 20);
            this.fnametxt.TabIndex = 1;
            this.fnametxt.Text = "First Name";
            this.fnametxt.TextChanged += new System.EventHandler(this.fnametxt_TextChanged);
            this.fnametxt.Enter += new System.EventHandler(this.fnametxt_Enter);
            this.fnametxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fnametxt_KeyDown);
            this.fnametxt.Leave += new System.EventHandler(this.fnametxt_Leave);
            // 
            // signUp
            // 
            this.signUp.BackColor = System.Drawing.Color.SlateGray;
            this.signUp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.signUp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.signUp.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.signUp.Location = new System.Drawing.Point(165, 241);
            this.signUp.Name = "signUp";
            this.signUp.Size = new System.Drawing.Size(117, 23);
            this.signUp.TabIndex = 4;
            this.signUp.Text = "Create New Account";
            this.signUp.UseVisualStyleBackColor = false;
            this.signUp.Click += new System.EventHandler(this.signUp_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(119, 211);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "don\'t have an account";
            // 
            // back
            // 
            this.back.BackColor = System.Drawing.Color.SlateGray;
            this.back.Cursor = System.Windows.Forms.Cursors.Hand;
            this.back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.back.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.back.Location = new System.Drawing.Point(76, 241);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(61, 23);
            this.back.TabIndex = 6;
            this.back.Text = "back";
            this.back.UseVisualStyleBackColor = false;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // log_in
            // 
            this.log_in.BackColor = System.Drawing.Color.SlateGray;
            this.log_in.Cursor = System.Windows.Forms.Cursors.Hand;
            this.log_in.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.log_in.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.log_in.Location = new System.Drawing.Point(136, 148);
            this.log_in.Name = "log_in";
            this.log_in.Size = new System.Drawing.Size(146, 48);
            this.log_in.TabIndex = 7;
            this.log_in.Text = "log in";
            this.log_in.UseVisualStyleBackColor = false;
            this.log_in.Click += new System.EventHandler(this.log_in_Click);
            // 
            // lnametxt
            // 
            this.lnametxt.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.lnametxt.Location = new System.Drawing.Point(136, 60);
            this.lnametxt.Name = "lnametxt";
            this.lnametxt.Size = new System.Drawing.Size(146, 20);
            this.lnametxt.TabIndex = 2;
            this.lnametxt.Text = "Last Name";
            this.lnametxt.TextChanged += new System.EventHandler(this.lnametxt_TextChanged);
            this.lnametxt.Enter += new System.EventHandler(this.lnametxt_Enter);
            this.lnametxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.lnametxt_KeyDown);
            this.lnametxt.Leave += new System.EventHandler(this.lnametxt_Leave);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(76, 34);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(38, 46);
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(76, 88);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(38, 38);
            this.pictureBox3.TabIndex = 10;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(76, 148);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(46, 48);
            this.pictureBox2.TabIndex = 11;
            this.pictureBox2.TabStop = false;
            // 
            // logIn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(374, 341);
            this.ControlBox = false;
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lnametxt);
            this.Controls.Add(this.log_in);
            this.Controls.Add(this.back);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.signUp);
            this.Controls.Add(this.fnametxt);
            this.Controls.Add(this.passtxt);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Name = "logIn";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "log in";
            this.Load += new System.EventHandler(this.LogIn_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox passtxt;
        private System.Windows.Forms.TextBox fnametxt;
        private System.Windows.Forms.Button signUp;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button back;
        private System.Windows.Forms.Button log_in;
        private System.Windows.Forms.TextBox lnametxt;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}